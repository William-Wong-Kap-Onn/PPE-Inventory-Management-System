package AssignmentCode;


import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author William
 */
public class CreateTextFile {
    public static void main(String[] args) {
        String fileName = "hospitals.txt";
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            // Write content to the file
            writer.write("This is hospital text file" );
            System.out.println("File written successfully.");
        } catch (IOException e) {
            // Handle the exception if something goes wrong
            System.out.println("An error occurred while writing the file.");
            e.printStackTrace();
        }
    }
}
